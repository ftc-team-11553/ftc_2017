package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.Range;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Gyroscope;
import com.qualcomm.robotcore.hardware.DcMotor;

@TeleOp

public class MotorTestOpMode extends LinearOpMode {
    private Gyroscope imu;
    private DcMotor motortest;
    private Servo servotest;
    private DistanceSensor sensorColorRange;
    private DigitalChannel digitalTouch;

    // todo: write your code here
    
    @Override
    public void runOpMode() {
        imu = hardwareMap.get(Gyroscope.class, "imu");
        motortest = hardwareMap.get(DcMotor.class, "motortest");
        servotest = hardwareMap.get(Servo.class, "servotest");
        sensorColorRange = hardwareMap.get(DistanceSensor.class, "sensorColorRange");
        digitalTouch = hardwareMap.get(DigitalChannel.class, "digitalTouch");
        
        telemetry.addData("Status", "Initialized");
        telemetry.update();
        
        digitalTouch.setMode(DigitalChannel.Mode.INPUT);
        
        // wait for diver to press play
        waitForStart();
        
        motortest.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motortest.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            
        servotest.setPosition(0.0);
        
        double tgtPower = 0;
        double tgtServo = 0;
        
        while (opModeIsActive())
        {
            tgtPower = -this.gamepad1.left_stick_y;
            
            tgtPower = Range.clip(tgtPower, -1, 1);
            motortest.setPower(tgtPower);
            
            int position = motortest.getCurrentPosition();
            double power = motortest.getPower();
            
            if (this.gamepad1.dpad_down && tgtServo > 0)
            {
                tgtServo -= 0.01;
            }
           
            if (this.gamepad1.dpad_up && tgtServo < 1)
            {
                tgtServo += 0.01;
            }
            
            tgtServo = Range.clip(tgtServo, 0, 1);           
            servotest.setPosition(tgtServo);
            
            String pressed = "";
            if (digitalTouch.getState() == false)
            {
                pressed = "PRESSED";
            }
            else
            {
                pressed = "NOT PRESSED";
            }
            
            telemetry.addData("Target Power", tgtPower);
            telemetry.addData("Motor Power", power);
            telemetry.addData("Motor Position", position);
            telemetry.addData("Servo Position", tgtServo);
            telemetry.addData("Distance (cm)", sensorColorRange.getDistance(DistanceUnit.CM));
            telemetry.addData("Button", pressed);
            telemetry.addData("Status", "Running");
            telemetry.update();
        }
    }
}
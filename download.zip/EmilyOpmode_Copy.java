package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.Range;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Gyroscope;
import com.qualcomm.robotcore.hardware.DcMotor;

@TeleOp

public class EmilyOpmode_Copy extends LinearOpMode {
    private Gyroscope imu;
    private DcMotor leftMotor;
    private DcMotor rightMotor;

    private Servo servotest;
    private DistanceSensor sensorColorRange;
    private DigitalChannel digitalTouch;

    // todo: write your code here
    
    @Override
    public void runOpMode() {
        imu = hardwareMap.get(Gyroscope.class, "imu");
        leftMotor = hardwareMap.get(DcMotor.class, "leftMotor");
        rightMotor = hardwareMap.get(DcMotor.class, "rightMotor");
        servotest = hardwareMap.get(Servo.class, "servotest");
        sensorColorRange = hardwareMap.get(DistanceSensor.class, "sensorColorRange");
        digitalTouch = hardwareMap.get(DigitalChannel.class, "digitalTouch");
        
        telemetry.addData("Status", "Initialized");
        telemetry.update();
        
        digitalTouch.setMode(DigitalChannel.Mode.INPUT);
        
        // wait for diver to press play
        waitForStart();
        
        leftMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        leftMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        rightMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            
        servotest.setPosition(0.0);
        
        double leftPower = 0;
        double rightPower = 0;
        double tgtServo = 0;
        
        while (opModeIsActive())
        {
            leftPower = this.gamepad1.left_stick_y;
            rightPower = -this.gamepad1.right_stick_y;
            
            leftPower = Range.clip(leftPower, -1, 1);
            leftMotor.setPower(leftPower);
            rightPower = Range.clip(rightPower, -1, 1);
            rightMotor.setPower(rightPower);
            
            int position = leftMotor.getCurrentPosition();
            double power = leftMotor.getPower();
            
            if (this.gamepad1.dpad_down && tgtServo > 0)
            {
                tgtServo -= 0.01;
            }
           
            if (this.gamepad1.dpad_up && tgtServo < 1)
            {
                tgtServo += 0.01;
            }
            
            tgtServo = Range.clip(tgtServo, 0, 1);           
            servotest.setPosition(tgtServo);
            
            String pressed = "";
            if (digitalTouch.getState() == false)
            {
                pressed = "PRESSED";
            }
            else
            {
                pressed = "NOT PRESSED";
            }
    
            telemetry.addData("Target Power", leftPower);
            telemetry.addData("Motor Power", power);
            telemetry.addData("Motor Position", position);
            telemetry.addData("Servo Position", tgtServo);
            telemetry.addData("Distance (cm)", sensorColorRange.getDistance(DistanceUnit.CM));
            telemetry.addData("Button", pressed);
            telemetry.addData("Status", "Running");
            telemetry.update();
        }
    }
}
